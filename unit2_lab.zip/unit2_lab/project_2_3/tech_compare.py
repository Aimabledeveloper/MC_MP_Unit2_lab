"""
Project 2.3 - WPAN / WLAN / WMAN range vs throughput vs power trade-off.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def load_dataset(path="tech_dataset.csv"):
    df = pd.read_csv(path)
    df["range_km"] = df["range_m"] / 1000
    df["power_dBm"] = 10 * np.log10(df["tx_power_mW"])
    df["rate_per_meter"] = df["rate_mbps"] / df["range_m"]   # figure of merit
    return df


def plot_tradeoff(df):
    colors = {"WPAN": "tab:blue", "WLAN": "tab:green", "WMAN": "tab:orange"}

    plt.figure(figsize=(7.5, 5))
    for _, r in df.iterrows():
        plt.scatter(r["range_m"], r["rate_mbps"],
                    s=r["tx_power_mW"], color=colors[r["class_"]],
                    alpha=0.6, edgecolor="k")
        plt.annotate(r["name"],
                     (r["range_m"], r["rate_mbps"]),
                     textcoords="offset points", xytext=(8, 6), fontsize=9)

    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("Typical range (m, log scale)")
    plt.ylabel("Peak data rate (Mbps, log scale)")
    plt.title("Range vs throughput trade-off\n(marker area proportional to Tx power)")
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()
    plt.savefig("plot_tradeoff.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    import os
    # Look for the CSV next to this script, regardless of where you run from.
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "tech_dataset.csv")
    df = load_dataset(csv_path)
    print(df.to_string(index=False))
    print("\nFigure of merit (Mbps per meter of range):")
    for _, r in df.iterrows():
        print(f"  {r['name']:22s} : {r['rate_per_meter']:8.4f} Mbps/m")
    plot_tradeoff(df)