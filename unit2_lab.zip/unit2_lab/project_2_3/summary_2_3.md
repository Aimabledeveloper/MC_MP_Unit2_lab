# Project 2.3 — Summary

## Comparison table
| Technology | Class | Range (m) | Rate (Mbps) | Tx power (mW) | Band |
|---|---|---|---|---|---|
| Bluetooth 5 (BLE) | WPAN | 50 | 2 | 10 | 2.4 GHz |
| Wi-Fi 6 (802.11ax) | WLAN | 100 | 9600 | 200 | 2.4/5/6 GHz |
| WiMAX (802.16e) | WMAN | 10000 | 70 | 2000 | 2.5/3.5 GHz |

Chart: `plot_tradeoff.png` — range (x) vs throughput (y), marker size ∝ Tx power.

## Scenario 1 — Smart home (40 sensors, battery)
**Requirements:** ≤ 5 Mbps per device, ≥ 1 year battery, coverage ≤ 30 m,
no licensed spectrum.

**Recommendation: Bluetooth 5 (BLE).** Its 2 Mbps rate comfortably exceeds
the 5 Mbps-per-device requirement at reduced duty cycle, its 10 mW transmit
power is the lowest in the table and supports multi-year coin-cell
operation, and 50 m range covers a typical home. Wi-Fi's 200 mW is too
power-hungry for coin cells; WiMAX requires licensed spectrum and masts.

**Secondary factors:** BLE's mature ecosystem and built-in mesh profiles
tip the balance further.

## Scenario 2 — University campus (thousands of devices, dense)
**Requirements:** ≥ 500 Mbps aggregate per AP, ~100 m cell radius, high
device density, unlicensed operation.

**Recommendation: Wi-Fi 6.** Its 9.6 Gbps peak easily supports the 500 Mbps
aggregate figure, 100 m coverage matches the per-AP cell radius, and
OFDMA/MU-MIMO handle dense device counts. BLE's 2 Mbps cannot scale, and
WiMAX lacks a client ecosystem on phones/laptops.

**Secondary factors:** unlicensed spectrum, ubiquitous client support.

## Scenario 3 — Metro fixed wireless link (5 km, LOS)
**Requirements:** 5–50 Mbps, 5 km link distance, outdoor mast with mains power.

**Recommendation: WiMAX (802.16e).** Its 10 km range covers the 5 km hop
with margin, 70 Mbps exceeds the 50 Mbps peak need, and the higher Tx power
(2 W) is acceptable on a mast. Wi-Fi cannot reach 5 km reliably; BLE's
50 m range is orders of magnitude short.

**Secondary factors:** licensed band gives interference protection; needs
a CPE at the far end.

## Sources
- Bluetooth SIG — Bluetooth 5 core specification (rate/power classes)
- IEEE 802.11ax / Wi-Fi Alliance — peak PHY rate
- IEEE 802.16e-2005 — Mobile WiMAX range/rate figures
- Rappaport, *Wireless Communications: Principles and Practice* — typical
  values; environment-dependent caveats noted in this table.