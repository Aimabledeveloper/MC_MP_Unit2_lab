# Project 2.1 — Summary

## Part (a): Friis path loss
The received power falls linearly on a log-distance plot. Doubling the distance
(1 km → 2 km) or the frequency (900 → 1800 MHz) produces a loss of **≈6.02 dB**
in every case, confirming the 20·log10() behavior in the Friis equation.

## Part (b): BPSK vs 16-QAM over AWGN
- The empirical BPSK BER curve sits on top of the theoretical 0.5·erfc(√Eb/N0)
  curve, validating the noise-scaling implementation.
- 16-QAM requires a higher Eb/N0 for the same BER because its 4 bits/symbol
  demand a denser constellation, making points more vulnerable to noise.
- At BER = 1e-3 the measured gap between the two curves is approximately
  **[FILL FROM YOUR OUTPUT]** dB.

## Link to Shannon–Hartley
Shannon–Hartley (C = B·log2(1+SNR)) shows that higher spectral efficiency
requires higher SNR in principle, but it describes an idealized
capacity-achieving code. Uncoded modulation always operates with a finite gap
below that ceiling, so the measured SNR gap is qualitatively consistent with —
but not numerically predicted by — Shannon–Hartley.