import numpy as np
import matplotlib.pyplot as plt

np.random.seed(0)

def friis_rx_power(Ptx_dBm, Gtx_dBi, Grx_dBi, d_km, f_MHz):
    return (Ptx_dBm + Gtx_dBi + Grx_dBi
            - 20*np.log10(d_km)
            - 20*np.log10(f_MHz)
            - 32.44)

if __name__ == "__main__":
    d = np.linspace(0.05, 10, 500)
    freqs = [900, 1900, 3500]
    Ptx, Gtx, Grx = 43, 15, 0

    plt.figure(figsize=(7,4.5))
    for f in freqs:
        plt.plot(d, friis_rx_power(Ptx,Gtx,Grx,d,f), label=f"{f} MHz")
    plt.xlabel("Distance (km)"); plt.ylabel("Received power (dBm)")
    plt.title("Friis free-space path loss")
    plt.grid(True, which="both", alpha=0.3); plt.legend()
    plt.tight_layout()
    plt.savefig("plot_friis.png", dpi=150); plt.show()

    # 6 dB doubling checks
    for f in freqs:
        diff = (friis_rx_power(Ptx,Gtx,Grx,1.0,f)
              - friis_rx_power(Ptx,Gtx,Grx,2.0,f))
        print(f"Distance doubling @ {f} MHz: {diff:.2f} dB")
    df = (friis_rx_power(Ptx,Gtx,Grx,1.0,900)
        - friis_rx_power(Ptx,Gtx,Grx,1.0,1800))
    print(f"Frequency doubling 900→1800 MHz: {df:.2f} dB")