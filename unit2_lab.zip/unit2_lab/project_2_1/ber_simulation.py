import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erfc

np.random.seed(0)

def bpsk_map(bits):
    return 2 * bits - 1

def qam16_map(bits):
    """Bulletproof Gray-coded 16-QAM, unit average energy."""
    b = bits.reshape(-1, 4)
    # 00->-3, 01->-1, 11->1, 10->3
    i_vals = np.array([-3, -1, 3, 1]) # index is [00, 01, 10, 11]
    q_vals = np.array([-3, -1, 3, 1])
    
    i_idx = b[:, 0]*2 + b[:, 1]
    q_idx = b[:, 2]*2 + b[:, 3]
    
    s = i_vals[i_idx] + 1j * q_vals[q_idx]
    return s / np.sqrt(10.0)

def qam16_demap(sym):
    """Minimum-distance slicer."""
    z = sym * np.sqrt(10.0)
    levels = np.array([-3, -1, 1, 3])
    
    I_idx = np.argmin(np.abs(z.real[:, None] - levels[None, :]), axis=1)
    Q_idx = np.argmin(np.abs(z.imag[:, None] - levels[None, :]), axis=1)
    
    # Reverse lookup: -3->00, -1->01, 1->11, 3->10
    inv_gray = np.array([[0,0], [0,1], [1,1], [1,0]])
    
    out = np.zeros((len(sym), 4), dtype=int)
    out[:, 0:2] = inv_gray[I_idx]
    out[:, 2:4] = inv_gray[Q_idx]
    return out.ravel()

def add_awgn(sym, EbN0_dB, k):
    EbN0 = 10 ** (EbN0_dB / 10)
    N0 = 1.0 / (k * EbN0)
    sigma = np.sqrt(N0 / 2)
    noise = sigma * (np.random.randn(*sym.shape) + 1j * np.random.randn(*sym.shape))
    return sym + noise

def gap_at_target(ebn0, ber, target=1e-3):
    valid = ber > 0
    log_ber = np.log10(ber[valid])
    lt = np.log10(target)
    for i in range(1, len(log_ber)):
        if log_ber[i] <= lt <= log_ber[i - 1]:
            frac = (lt - log_ber[i - 1]) / (log_ber[i] - log_ber[i - 1])
            ebn0_valid = ebn0[valid]
            return ebn0_valid[i - 1] + frac * (ebn0_valid[i] - ebn0_valid[i - 1])
    return np.nan

if __name__ == "__main__":
    Nbits = 2_000_000  # 2 million bits gives a much smoother curve
    EbN0_dB = np.arange(0, 17, 2)
    bits = np.random.randint(0, 2, size=Nbits)

    ber_bpsk = []
    for e in EbN0_dB:
        s = bpsk_map(bits)
        r = add_awgn(s, e, k=1).real
        bits_hat = (r > 0).astype(int)
        ber = np.mean(bits_hat != bits)
        ber_bpsk.append(ber if ber > 0 else np.nan)

    bits16 = bits[: (Nbits // 4) * 4]
    ber_qam = []
    for e in EbN0_dB:
        s = qam16_map(bits16)
        r = add_awgn(s, e, k=4)
        bits_hat = qam16_demap(r)
        ber = np.mean(bits_hat != bits16)
        ber_qam.append(ber if ber > 0 else np.nan)

    EbN0_lin = 10 ** (EbN0_dB / 10)
    ber_theory = 0.5 * erfc(np.sqrt(EbN0_lin))

    plt.figure(figsize=(7, 5))
    plt.semilogy(EbN0_dB, ber_theory, "k--", label="BPSK theory")
    plt.semilogy(EbN0_dB, ber_bpsk, "o-", label="BPSK sim")
    plt.semilogy(EbN0_dB, ber_qam, "s-", label="16-QAM sim")
    plt.xlabel("Eb/N0 (dB)")
    plt.ylabel("BER")
    plt.title("BER vs Eb/N0 over AWGN")
    plt.grid(True, which="both", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("plot_ber.png", dpi=150)
    plt.show()

    g_b = gap_at_target(EbN0_dB, np.array(ber_bpsk), 1e-3)
    g_q = gap_at_target(EbN0_dB, np.array(ber_qam), 1e-3)
    print(f"\nBPSK   Eb/N0 @ BER=1e-3 : {g_b:.2f} dB")
    print(f"16-QAM Eb/N0 @ BER=1e-3 : {g_q:.2f} dB")
    print(f"Gap (16-QAM - BPSK)      : {g_q - g_b:.2f} dB")