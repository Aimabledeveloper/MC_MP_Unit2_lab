import numpy as np
import matplotlib.pyplot as plt

np.random.seed(1)
N = 64
Ncp = 16

def qpsk_map(bits):
    b = bits.reshape(-1, 2)
    s = (1 - 2 * b[:, 0]) + 1j * (1 - 2 * b[:, 1])
    return s / np.sqrt(2)

def ofdm_modulate(sym_freq, Ncp):
    x = np.fft.ifft(sym_freq)
    cp = x[-Ncp:] if Ncp > 0 else np.array([], dtype=complex)
    return np.concatenate([cp, x])

def ofdm_demodulate(y, Ncp):
    x = y[Ncp:Ncp + N]
    return np.fft.fft(x)

h = np.array([1.0, 0.6 + 0.3j, 0.35 - 0.2j])
delays = np.array([0, 3, 7])

# Build the true channel FIR filter (pad with zeros up to max delay + 1)
h_fir = np.zeros(8, dtype=complex)
for g, d in zip(h, delays):
    h_fir[d] = g

# Channel frequency response for Zero-Forcing Equalization
H = np.fft.fft(h_fir, N)

def channel(x, h_fir):
    """Standard FIR convolution simulating multipath."""
    return np.convolve(x, h_fir, mode='full')[:len(x)]

def self_checks():
    print("--- Self-checks ---")
    test_sym = qpsk_map(np.random.randint(0, 2, 2 * N))
    tx = ofdm_modulate(test_sym, Ncp)
    rx = ofdm_demodulate(tx, Ncp)
    print(f"Noiseless IFFT/FFT max error : {np.max(np.abs(rx - test_sym)):.2e}")
    x = np.fft.ifft(test_sym)
    cp = tx[:Ncp]
    print(f"CP equals tail of IFFT       : {np.allclose(cp, x[-Ncp:])}")

def run_constellation_demo():
    Nsym = 3
    syms = [qpsk_map(np.random.randint(0, 2, 2 * N)) for _ in range(Nsym)]

    L = N + Ncp
    tx_cp = np.concatenate([ofdm_modulate(s, Ncp) for s in syms])
    rx_cp = channel(tx_cp, h_fir)
    
    # Apply Zero-Forcing Equalization
    rec_with = [ofdm_demodulate(rx_cp[i * L:i * L + L], Ncp) / H for i in range(Nsym)]

    tx_nocp = np.concatenate([np.fft.ifft(s) for s in syms])
    rx_nocp = channel(tx_nocp, h_fir)
    
    # Apply Zero-Forcing Equalization
    rec_nocp = [np.fft.fft(rx_nocp[i * N:(i + 1) * N]) / H for i in range(Nsym)]

    def mse(rec_list):
        return np.mean([np.mean(np.abs(r - t) ** 2) for r, t in zip(rec_list, syms)])

    print("\n--- Constellation comparison ---")
    print(f"MSE with CP    : {mse(rec_with):.4e}")
    print(f"MSE without CP : {mse(rec_nocp):.4e}")

    fig, ax = plt.subplots(1, 2, figsize=(10, 4.5))
    ax[0].scatter(np.concatenate([r.real for r in rec_with]),
                  np.concatenate([r.imag for r in rec_with]), s=14, alpha=0.7)
    ax[0].set_title(f"With CP (Ncp={Ncp} > max delay=7)")

    ax[1].scatter(np.concatenate([r.real for r in rec_nocp]),
                  np.concatenate([r.imag for r in rec_nocp]), s=14, alpha=0.7, color="tab:red")
    ax[1].set_title("Without CP")

    for a in ax:
        a.set_xlabel("I")
        a.set_ylabel("Q")
        a.grid(alpha=0.3)
        a.set_aspect("equal")

    plt.tight_layout()
    plt.savefig("plot_constellations.png", dpi=150)
    plt.show()

def run_cp_sweep():
    Nsym = 3
    syms = [qpsk_map(np.random.randint(0, 2, 2 * N)) for _ in range(Nsym)]

    def mse_for_cp(Ncp_test):
        L = N + Ncp_test
        tx = np.concatenate([ofdm_modulate(s, Ncp_test) for s in syms])
        rx = channel(tx, h_fir)
        
        recs = [ofdm_demodulate(rx[i * L:i * L + L], Ncp_test) / H for i in range(Nsym)]
        
        mse_val = np.mean([np.mean(np.abs(r - t) ** 2) for r, t in zip(recs, syms)])
        return mse_val + 1e-16 

    cp_vals = [0, 2, 4, 6, 7, 8, 12, 16, 24, 32]
    mses = [mse_for_cp(c) for c in cp_vals]

    print("\n--- CP sweep ---")
    for c, m in zip(cp_vals, mses):
        print(f"Ncp={c:2d}  MSE={m:.4e}")

    plt.figure(figsize=(7, 4.5))
    plt.semilogy(cp_vals, mses, "o-")
    plt.axvline(7, color="gray", ls="--", label="max channel delay = 7")
    plt.xlabel("CP length (samples)")
    plt.ylabel("MSE")
    plt.title("MSE vs CP length")
    plt.grid(True, which="both", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("plot_cp_sweep.png", dpi=150)
    plt.show()

if __name__ == "__main__":
    self_checks()
    run_constellation_demo()
    run_cp_sweep()