# Project 2.2 — Summary

## Dual role of the cyclic prefix
The cyclic prefix acts simultaneously as a **guard interval** and a
**cyclic extension**. As a guard interval it absorbs the tail of the previous
symbol's multipath response before the receiver's FFT window starts, so
delayed echoes from symbol k−1 cannot leak into symbol k. As a cyclic
extension it makes the linear convolution with the channel equivalent to a
circular convolution inside the FFT window, so each subcarrier sees only a
complex scalar gain — orthogonality is preserved and the FFT inverts the
channel exactly.

## Interpretation of the CP-length sweep
The MSE-vs-CP plot shows three regimes:
1. **Ncp < max delay (~7 samples)** — ISI and ICI are present; MSE is high.
2. **Ncp ≈ max delay** — error collapses sharply; the CP just covers the
   channel's dispersion.
3. **Ncp > max delay** — MSE plateaus at the numerical floor (noise-free
   case), because extra CP samples only consume bandwidth without adding
   protection.

This threshold-then-plateau behaviour is the direct fingerprint of the CP's
dual role.